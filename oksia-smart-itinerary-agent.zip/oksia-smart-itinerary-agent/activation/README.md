# Activation module placeholder

This folder holds the plugin activation / license flow that was removed from the live site build.
Use these files later for Version 2 if activation is reintroduced.
